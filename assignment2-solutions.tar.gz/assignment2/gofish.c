#include <stdio.h>
#include "deck.h"
#include "player.h"
#include <time.h>
#include <unistd.h>
int main(int args, char* argv[]) 
{
  	//char rank[3];
	srand(time(0));
	struct player player1;
	struct player player2;
	player1.card_list = (struct hand*)malloc(sizeof(struct hand));
	player2.card_list = (struct hand*)malloc(sizeof(struct hand));
	//for(int j=0;j<30;j++){add_card(&player1,next_card());}
	char played;
	//char played[3];
	char playAgain[2] = {'Y','N'} ;
	char rank[3];
	//printf("\nDo you want to play again [Y/N]: ");
                // scanf("%c",playAgain);
	while(playAgain[0] =='Y'){
		//reset_player(&player1);
		//reset_player(&player2);
		printf("Shuffling deck ...\n");
        	shuffle();
        	deal_player_cards(&player1);
        	deal_player_cards(&player2);
		int gameOver = 0;
		while(gameOver == 0){
			int p2turn = 1;
			while(p2turn ==1 && gameOver !=1){
				if (player1.hand_size == 0){add_card(&player1,next_card());}
                        	if (player2.hand_size == 0){add_card(&player1,next_card());}
				check_add_book(&player1);
				check_add_book(&player2);
                        	printf("\nPlayer 1's Hand - ");
                        	print_hand(&player1);
                        	printf("\nPlayer 1's Book - ");
                        	for(int j=0;j<player1.book_count;j++){printf("%c ",player1.book[j]);}
                        	printf("\nPlayer 2's Book - ");
                        	for(int j=0;j<player2.book_count;j++){printf("%c ",player2.book[j]);}
                        	printf("\nPlayer 1's Turn,");
				played = user_play(&player1);
				//computer_play(&player1,played);
				p2turn = search(&player2,played);
				//p2turn = search(&player2,played[0]);
				if (p2turn ==0 && played =='1'){
				//if(p2turn == 0 && played[0] == '1'){
					printf("\n     -Player 2 has no 10's");
				}
				else if(p2turn == 0){printf("\n     -Player 2 has no %c's",played);}
				//else if(p2turn == 0){printf("\n       -Player 2 has no %c's",played[0]);}
				if (p2turn == 0){
					if(deck_size() >0){
						add_card(&player1, next_card());
						printf("\n     -Go Fish, Player 1 draws %s%c",(&player1)->card_list ->top.rank,(&player1)->card_list ->top.suit);
						if((&player1)->card_list ->top.rank[0] == played){
							printf("\n     -Player 1 gets another turn\n");
							p2turn = 1;
						}
						else{printf("\n     -Player 2's turn\n");}
					}
					else{printf("\nThere are no more cards in the deck, so the game is over");
						if(player1.book_count > player2.book_count){printf("\nPlayer 1 wins %d -%d",player1.book_count,player2.book_count);}
						if(player2.book_count > player1.book_count){printf("\nPlayer 2 wins %d -%d",player2.book_count,player1.book_count);}
						else{printf("\nPlayer1 and Player 2 Tied!");}
						printf("\nDo you want to play again [Y/N]: ");
						scanf(" %c",playAgain);
						if(playAgain[0] == 'Y'){reset_player(&player1);reset_player(&player2); gameOver = 0;}
						else{
							gameOver = 1;
							break;
						}
					}
				}
				else{
					int transfer_return = transfer_cards(&player2,&player1,played);
					//int transfer_return = transfer_cards(&player2,&player1,played[0]);
					if (transfer_return == 1){
						if(played == '1'){printf("\n     -Player 2 has 1 10\n");}
						//if(played[0] == '1'){printf("\n    -Player 2 has 1 10\n");}
						else{printf("\n     -Player 2 has 1 %c",played);}
						//else{printf("\n       -Player 2 has 1 %c",played[0]);}
					}
					else{
						if(played == '1'){printf("\n     -Player 2 has %d 10's",transfer_return);}
						//if(played[0] == '1'){printf("\n  -Player 2 has %d 10's",transfer_return);}
						else {printf("	-Player 2 has %d %c's\n",transfer_return, played);}
						//else {printf("        -Player 2 has %d %c's\n",transfer_return, played[0]);}
					}
				}
			if(player2.book_count >= 7){gameOver = 1;}
                         if(player1.book_count >= 7){gameOver = 1;}
			};
			int p1turn = 1;
			 if(player2.book_count >= 7){gameOver = 1;}
                         if(player1.book_count >= 7){gameOver = 1;}
			while(p1turn == 1 && gameOver !=1){
				if(player1.hand_size == 0){add_card(&player1,next_card());}
                        	if(player2.hand_size == 0){add_card(&player2,next_card());}
				check_add_book(&player1);
				check_add_book(&player2);
                        	printf("\nPlayer 1's Hand - ");
                        	print_hand(&player1);
                        	printf("\nPlayer 1's Book - ");
                        	for(int j=0;j<player1.book_count;j++){printf("%c ",player1.book[j]);}
                        	printf("\nPlayer 2's Book - ");
                        	for(int j=0;j<player2.book_count;j++){printf("%c ",player2.book[j]);}
                        	printf("\nPlayer 2's turn,");
				computer_play(&player2,rank);
				p1turn = search(&player1,rank[0]);
				printf(" %s\n",rank);
				//if(rank[0] == 'T'){rank[0] = '1';}
				if(p1turn == 0 && rank[0] == '1'){printf("\n     -Player 1 has no 10's");}
				else if(p1turn == 0){printf("\n     -Player 1 has no %c's",rank[0]);}
				if(p1turn == 0){
					if(deck_size()>0){
						add_card(&player2,next_card());
						printf("\n     -Go Fish, Player 2 draws a card");
                                                if((&player2)->card_list ->top.rank[0] == rank[0]){
                                                        printf("\n     -Player 2 gets another turn\n");
                                                        p1turn = 1;
                                                }
                                                else{printf("\n     -Player 1's turn\n");}
					}
					else{printf("\nThere are no more cards in the deck, so the game is over");
						if(player1.book_count > player2.book_count){printf("\nPlayer 1 wins %d -%d",player1.book_count,player2.book_count);}
                                                if(player2.book_count > player1.book_count){printf("\nPlayer 2 wins %d -%d",player2.book_count,player1.book_count);}
                                                else{printf("\nPlayer1 and Player 2 Tied!");}
						printf("\nDo you want to play again [Y/N]: ");
                                                scanf(" %c",playAgain);
						if(playAgain[0] == 'Y'){reset_player(&player1);reset_player(&player2); gameOver = 0;}
                                                else{
                                                        gameOver = 1;
                                                        break;
                                                }
					}
				}
				else{
					int transfer_return = transfer_cards(&player1,&player2,rank[0]);
                                        if (transfer_return == 1){
                                                if(rank[0] == '1'){printf("\n     -Player 1 has 1 10\n");}
                                                else{printf("\n     -Player 1 has 1 %c",rank[0]);}
                                        }
                                        else{
                                                if(rank[0] == '1'){printf("\n     -Player 1 has %d 10's",transfer_return);}
                                                else {printf("  -Player 1 has %d %c's\n",transfer_return, rank[0]);}
                                        }
				}
			}
		}
		if(player1.book_count >= 7){printf("\nPlayer 1 Wins ! %d-%d",player1.book_count,player2.book_count);
			printf("\nDo you want to play again [Y/N]: ");
                 	scanf(" %c",playAgain);
                 	if(playAgain[0] =='Y'){
                        reset_player(&player1);
                        reset_player(&player2);
                	}
		}
		if(player2.book_count >= 7){printf("\nPlayer 2 Wins ! %d-%d",player2.book_count,player1.book_count);
			printf("\nDo you want to play again [Y/N]: ");
                 	scanf(" %c",playAgain);
                 	if(playAgain[0] =='Y'){
                        reset_player(&player1);
                        reset_player(&player2);
                	}
		}
	}
	printf("Exiting\n");
	return 0;

}

