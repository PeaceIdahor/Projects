//#ifndef PLAYER_H
//#define PLAYER_H
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "card.h"
#include "player.h"
#include <string.h>
int atoi(const char *str);
/*
 * Structure: player
 * -----------------
 *  Each player holds some number of cards in their hand
 *  Each player can have at most 7 "books" before winning 
 */

/*
 * Function: add_card
 * -------------------
 *  Add a new card to the player's hand. 
 *
 *  target: the target player
 *  new_card: pointer to the new card to add
 *
 *  returns: return 0 if no error, non-zero otherwise
 */
int add_card(struct player* target, struct card* new_card) {
	//allocating space
	struct hand* temp;
	temp = (struct hand*)malloc(sizeof(struct hand)); //create space and pointer for new element in linked list
	if (temp == NULL) {return -1;}
	// initialize new elem
	temp ->top = *new_card;
	temp->next = target -> card_list;
	target -> card_list = temp;
	++target -> hand_size;
	return 0;
};
/*
 * Function: remove_card
 * ---------------------
 *  Remove a card from the player's hand. 
 *
 *  target: the target player
 *  old_card: pointer to the old card to remove
 *
 *  returns: return 0 if no error, non-zero otherwise
 */
int remove_card(struct player* target, struct card* old_card){
	struct hand* iterator = target -> card_list;
	iterator = (struct hand*)malloc(sizeof(struct hand));
	iterator =  target -> card_list;
	struct hand* previous= NULL;
	if (iterator == NULL){return -1;};
	while (iterator->top.rank[0] != old_card->rank[0] || iterator->top.suit != old_card->suit) {
		previous = iterator;
		iterator = iterator->next;
		if (iterator == NULL) {return -1;} 
	};
	if (previous !=NULL){
		previous -> next = iterator ->next;} //to remove item, connect "next" pointer to the item behind it and free memory
	else{
		target -> card_list = iterator->next;} //if removing first item, then move card list pointer to second item
	free(iterator);
	--target->hand_size;
	return 0;
};
//Function: Print out each item in player's hand in order
int print_hand(struct player* target) {
	struct hand* temp;
	temp = (struct hand*)malloc(sizeof(struct hand));
	temp = target -> card_list;
	for(int i=0; i< target->hand_size;i++) {
		if(temp == NULL){return -1;}
		printf("%s%c ",temp ->top.rank,temp ->top.suit);
		temp = temp->next;
	};
	return 0;
};
/*
 * Function: check_add_book
 * ------------------------
 *  Check if a player has all 4 cards of the same rank.
 *  If so, remove those cards from the hand, and add the rank to the book.
 *  Returns after finding one matching set of 4, so should be called after adding each a new card.
 * 
 *  target: pointer to the player to check
 *  
 *  Return: a char that indicates the book that was added; return 0 if no book added.
 */
char check_add_book(struct player* target) {
	struct hand* temp;
	int countRanksArray[13]={0};
	temp = (struct hand*)malloc(sizeof(struct hand));
	temp = target -> card_list;
	char returnedChar = '0';
	for (int i=0; i< target->hand_size;i++) {
		//printf("%s%c",(*temp).top.rank, (*temp).top.suit);
		if (*(*temp).top.rank == 'A') {++countRanksArray[0];}
		else if (*(*temp).top.rank == 'J') {++countRanksArray[10];}
		else if (*(*temp).top.rank == 'Q') {++countRanksArray[11];}
		else if (*(*temp).top.rank == 'K') {++countRanksArray[12];}
		//else if (atoi((*temp).top.rank) > 1) {
		else {   //think this works as a substitute for above line
		++countRanksArray[atoi((*temp).top.rank)-1];};
		temp = temp->next;
	};
	for (int j=0; j<13;j++) {
		//from here, if any value of countRanksArray is 4 then add to book and recurse
		if(countRanksArray[j] ==4) {
			struct card removed;
			char stored;
			returnedChar = 'Y';
			if(j==0) {stored ='A';}
			else if(j==9) {stored ='T';}
			else if(j==10) {stored ='J';}
			else if(j==11) {stored ='Q';}
			else if(j==12) {stored ='K';}
			else {
			sprintf(&stored,"%d",j+1);
			//printf("%c",stored);
			};
			target->book[target->book_count]=stored;
			++target->book_count;
			//remove the 4 in a set
			char suits[4] = {'D','H','S','C'};
			for (int u=0;u<7;u++) {
			if(target->book[u] == 'T') {
				removed.rank[0] ='1';
				removed.rank[1] ='0';
			}
			else {removed.rank[0] = target->book[u];}
			for (int j=0;j<4;j++) {
			removed.suit = suits[j];
			//printf("%s%c",removed.rank,removed.suit);
			remove_card(target,&removed);
			}
			}
		};
	};
	return returnedChar;
};

/*
 * Function: search
 * ----------------
 *  Search a player's hand for a requested rank.
 *  
 *  rank: the rank to search for
 *  target: the player (and their hand) to search
 *
 *  Return: If the player has a card of that rank, return 1, else return 0
 */
//	while (iterator->top.rank != old_card->rank || iterator->top.suit != old_card->suit) {

int search(struct player* target, char rank){
        struct hand* iterator;
	iterator = (struct hand*)malloc(sizeof(struct hand));
	iterator =  target -> card_list;
	while(iterator != NULL){
		if(iterator ->top.rank[0] == rank){
			return 1;
		}
		iterator = iterator ->next;
	}
	return 0;
}
void printRank(struct player* target, char rank) {
 	struct hand* last;
	last = (struct hand*)malloc(sizeof(struct hand));
	last = target->card_list->next;
  	while(last != NULL) {
    		if(last->top.rank[0]== rank){
      			printf("%c%c ", last->top.rank[0], last->top.suit);
    		}
    		last = last->next;
  	}
  	printf("\n");
}
 
/*
 * Function: transfer_cards
 * ------------------------
 *   Transfer cards of a given rank from the source player's 
 *   hand to the destination player's hand. Remove transferred
 *   cards from the source player's hand. Add transferred cards
 *   to the destination player's hand.
 *   
 *   src: a pointer to the source player
 *   dest: a pointer to the destination player
 *   rank: the rank to transfer
 *
 *   Return: 0 if no cards found/transferred, <0 if error, otherwise 
 *   return value indicates number of cards transferred
 */   
int transfer_cards(struct player* src, struct player* dest, char rank) {
	struct hand* temp = src -> card_list;
	struct hand* tranfers[4];
	int count = 0;
	while(temp != NULL){
		if(temp ->top.rank[0] == rank){
			tranfers[count] = temp;
			count++;
		}
		temp = temp ->next;
	}
	for(int i = 0; i< count; i++){
		add_card(dest, &(tranfers[i] ->top));
		remove_card(src,&(tranfers[i] ->top));
	}
	return count;
}
/*
 * Function: game_over
 * -------------------
 *   Boolean function to check if a player has 7 books yet
 *   and the game is over
 *
 *   target: the player to check
 *   
 *   Return: 1 if game is over, 0 if game is not over
 */
int game_over(struct player* target) {
	if (target->book_count ==7) {return 1;}
	else {return 0;}
};
/* 
 * Function: reset_player
 * ----------------------
 *
\ *   Reset player by free'ing any memory of cards remaining in hand,
 *   and re-initializes the book.  Used when playing a new game.
 * 
 *   target: player to reset
 * 
 *   Return: 0 if no error, and non-zero on error.
 */
int reset_player(struct player* target){
	for(int i=0; i<7;i++){
		target ->book[i] = '0';
	}
	target ->book_count = 0;
	struct hand* next = NULL;
	struct hand* iterator = target -> card_list;
	for(int h = 0; h< target ->hand_size;h++){
		if(iterator ==NULL){return 1;}
		free(iterator);
   		iterator= (struct hand*)malloc(sizeof(struct hand));
		iterator = next;
	}
	return 0;
};

/* 
 * Function: computer_play
 * -----------------------
 *
 *   Select a rank randomly to play this turn. The player must have at least
 *   one card of the selected rank in their hand.
 *
 *   target: the player's hand to select from
 *
 *   Rank: return a valid selected rank
 */
int computer_play(struct player* target, char* result){
	char ranksArray[target->hand_size][3];
	struct hand* iterator = target->card_list;
	if(iterator ==NULL){return -1;}
	for(int i=0; i< target->hand_size;i++) {
		if(iterator ==NULL){return -1;}
		ranksArray[i][0]=*(iterator->top).rank;
		if (ranksArray[i][0] == '1') {ranksArray[i][1]='0';};
		iterator=iterator->next;
		if(iterator ==NULL){return -1;}
	}
	int rando = rand()%target->hand_size;
	result[0] = ranksArray[rando][0];
	if(ranksArray[rando][0]=='1'){
		result[1] = ranksArray[rando][1];
		result[2] = '\0';}
	else {result[1] ='\0';}
	return 0;
};
/* 
 * Function: user_play
 * -------------------
 *
 *   Read standard input to get rank user wishes to play.  Must perform error
 *   checking to make sure at least one card in the player's hand is of the 
 *   requested rank.  If not, print out "Error - must have at least one card from rank to play"
 *   and then re-prompt the user.
 *
 *   target: the player's hand to check
 * 
 *   returns: return a valid selected rank
 */
char user_play(struct player* target){
	while(target ->hand_size !=0){
		char rank[3];
		printf(" enter a Rank - ");
		scanf("%s",rank);
		rank[2] = '\0';
		int searchCheck = search(target,rank[0]);
		//printf("\n rank = %s searchCheck = %d ",rank,searchCheck);
		if(searchCheck == 1){
			return rank[0];}
		else {printf("Error - must have at least one card from rank to play \n");}
	}
	return'0';
};

