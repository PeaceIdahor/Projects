#include <stdio.h>
#include <stdlib.h>
#include "deck.h"
int shuffle(){
	deck_instance = *(struct deck*)malloc(sizeof(struct deck));
	char rank[13] = {'2','3','4','5','6','7','8','9','T','J','Q','K','A'};
	char suit[4] = {'S','D','C','H'};
	for (int i=0;i<4;i++){
		for (int j=0;j<13;j++){
			deck_instance.list[i*13+j].suit = suit[i];
			if(rank[j] == 'T'){
				deck_instance.list[i*13+j].rank[0] = '1';
				deck_instance.list[i*13+j].rank[1] = '0';
			}
			else{
				deck_instance.list[i*13+j].rank[0] = rank[j];
			};
		};
	};
	//Generate 2 arrays, loop through them to create cards
	// Now we need to shuffle through randomization
	int rand1;
	int rand2;
	int max = 51;
	for (int i=0;i<500;i++){
		rand1 = rand()%max;
		rand2 = rand()%max;
		struct card temp = deck_instance.list[rand1];
		deck_instance.list[rand1] = deck_instance.list[rand2];
		deck_instance.list[rand2] = temp;
		//printf("suit %c rank %s ", deck_instance.list[rand1].suit, deck_instance.list[rand1].rank);
	};
	deck_instance.top_card = deck_instance.list[0];      //commented out shuffling for tests
	return 0;
};
int deal_player_cards(struct player* target){
	target->hand_size = 0;
	target->book_count =0;
	for (int i=0;i<7;i++){
		target->book[i] = '0';
		add_card(target,next_card());
		//printf("%s%c ",deck_instance.top_card.rank,deck_instance.top_card.suit
	};
	return 0;
};
size_t deck_size () {
	size_t sizeReturn;
	sizeReturn = 0;
	for(int i = 0; i<52;i++) {
		if(deck_instance.list[i].suit != 'Z') {++sizeReturn;};
	};
	return sizeReturn;
};
struct card* next_card( ) {
	struct card* temp;
	temp = (struct card*)malloc(sizeof(struct card)); 
	temp = &deck_instance.top_card;
	for (int i=0;i<deck_size()-1;i++) { //need to replace 51 with deck_size -1
		deck_instance.list[i] = deck_instance.list[i+1];};
	deck_instance.top_card = deck_instance.list[0];
	deck_instance.list[deck_size()-1].suit = 'Z';
	return temp;
}; //has to return a pointer to top card, then remove it from deck

