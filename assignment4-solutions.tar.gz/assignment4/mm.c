/*-------------------------------------------------------------------  
  Peace Idahor and Owen Ross      
we attempted the realloc function, we went to the TA jiaya and he recorded our names                   
 * Lab 5 Starter code:                                                                            
 *        single doubly-linked free block list with LIFO policy                                  
 *        with support for coalescing adjacent free blocks  
 *
 * Terminology:
 * o We will implement an explicit free list allocator
 * o We use "next" and "previous" to refer to blocks as ordered in
 *   the free list.
 * o We use "following" and "preceding" to refer to adjacent blocks
 *   in memory.
 *-------------------------------------------------------------------- */
 
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
 
#include "memlib.h"
#include "mm.h"
 
/* Macros for unscaled pointer arithmetic to keep other code cleaner.  
   Casting to a char* has the effect that pointer arithmetic happens at
   the byte granularity (i.e. POINTER_ADD(0x1, 1) would be 0x2).  (By
   default, incrementing a pointer in C has the effect of incrementing
   it by the size of the type to which it points (e.g. BlockInfo).)
   We cast the result to void* to force you to cast back to the
   appropriate type and ensure you don't accidentally use the resulting
   pointer as a char* implicitly.  You are welcome to implement your
   own pointer arithmetic instead of using these macros.
*/
#define UNSCALED_POINTER_ADD(p,x) ((void*)((char*)(p) + (x)))
#define UNSCALED_POINTER_SUB(p,x) ((void*)((char*)(p) - (x)))
 
 
/******** FREE LIST IMPLEMENTATION ***********************************/
 
 
/* A BlockInfo contains information about a block, including the size
   and usage tags, as well as pointers to the next and previous blocks
   in the free list.  This is exactly the "explicit free list" structure
   illustrated in the lecture slides.
   
   Note that the next and prev pointers and the boundary tag are only
   needed when the block is free.  To achieve better utilization, mm_malloc
   should use the space for next and prev as part of the space it returns.
 
   +--------------+
   | sizeAndTags  |  <-  BlockInfo pointers in free list point here
   |  (header)    |
   +--------------+
   |     next     |  <-  Pointers returned by mm_malloc point here
   +--------------+
   |     prev     |
   +--------------+
   |  space and   |
   |   padding    |
   |     ...      |
   |     ...      |
   +--------------+
   | boundary tag |
   |  (footer)    |
   +--------------+
*/
struct BlockInfo {
  // Size of the block (in the high bits) and tags for whether the
  // block and its predecessor in memory are in use.  See the SIZE()
  // and TAG macros, below, for more details.
  size_t sizeAndTags;
  // Pointer to the next block in the free list.
  struct BlockInfo* next;
  // Pointer to the previous block in the free list.
  struct BlockInfo* prev;
};
typedef struct BlockInfo BlockInfo;
 
 
/* Pointer to the first BlockInfo in the free list, the list's head.
   
   A pointer to the head of the free list in this implementation is
   always stored in the first word in the heap.  mem_heap_lo() returns
   a pointer to the first word in the heap, so we cast the result of
   mem_heap_lo() to a BlockInfo** (a pointer to a pointer to
   BlockInfo) and dereference this to get a pointer to the first
   BlockInfo in the free list. */
#define FREE_LIST_HEAD *((BlockInfo **)mem_heap_lo())
 
/* Size of a word on this architecture. */
#define WORD_SIZE sizeof(void*)
 
/* Minimum block size (to account for size header, next ptr, prev ptr,
   and boundary tag) */
#define MIN_BLOCK_SIZE (sizeof(BlockInfo) + WORD_SIZE)
 
/* Alignment of blocks returned by mm_malloc. */
#define ALIGNMENT 8
 
/* SIZE(blockInfo->sizeAndTags) extracts the size of a 'sizeAndTags' field.
   Also, calling SIZE(size) selects just the higher bits of 'size' to ensure
   that 'size' is properly aligned.  We align 'size' so we can use the low
   bits of the sizeAndTags field to tag a block as free/used, etc, like this:
   
      sizeAndTags:
      +-------------------------------------------+
      | 63 | 62 | 61 | 60 |  . . . .  | 2 | 1 | 0 |
      +-------------------------------------------+
        ^                                       ^
      high bit                               low bit
 
   Since ALIGNMENT == 8, we reserve the low 3 bits of sizeAndTags for tag
   bits, and we use bits 3-63 to store the size.
 
   Bit 0 (2^0 == 1): TAG_USED
   Bit 1 (2^1 == 2): TAG_PRECEDING_USED
*/
#define SIZE(x) ((x) & ~(ALIGNMENT - 1))
 
/* TAG_USED is the bit mask used in sizeAndTags to mark a block as used. */
#define TAG_USED 1
 
/* TAG_PRECEDING_USED is the bit mask used in sizeAndTags to indicate
   that the block preceding it in memory is used. (used in turn for
   coalescing).  If the previous block is not used, we can learn the size
   of the previous block from its boundary tag */
#define TAG_PRECEDING_USED 2
 
 
/* Find a free block of the requested size in the free list.  Returns
   NULL if no free block is large enough. */
static void * searchFreeList(size_t reqSize) {  
  BlockInfo* freeBlock;
 
  freeBlock = FREE_LIST_HEAD;
  while (freeBlock != NULL){
    if (SIZE(freeBlock->sizeAndTags) >= reqSize) {
      return freeBlock;
    } else {
      freeBlock = freeBlock->next;
    }
  }
  return NULL;
}
           
/* Insert freeBlock at the head of the list.  (LIFO) */
static void insertFreeBlock(BlockInfo* freeBlock) {
  BlockInfo* oldHead = FREE_LIST_HEAD;
  freeBlock->next = oldHead;
  if (oldHead != NULL) {
    oldHead->prev = freeBlock;
  }
  //  freeBlock->prev = NULL;
  FREE_LIST_HEAD = freeBlock;
}      
 
/* Remove a free block from the free list. */
static void removeFreeBlock(BlockInfo* freeBlock) {
  BlockInfo *nextFree, *prevFree;
 
  nextFree = freeBlock->next;
  prevFree = freeBlock->prev;
 
  // If the next block is not null, patch its prev pointer.
  if (nextFree != NULL) {
    nextFree->prev = prevFree;
  }
 
  // If we're removing the head of the free list, set the head to be
  // the next block, otherwise patch the previous block's next pointer.
  if (freeBlock == FREE_LIST_HEAD) {
    FREE_LIST_HEAD = nextFree;
  } else {
    prevFree->next = nextFree;
  }
}
 
/* Coalesce 'oldBlock' with any preceeding or following free blocks. */
static void coalesceFreeBlock(BlockInfo* oldBlock) {
  BlockInfo *blockCursor;
  BlockInfo *newBlock;
  BlockInfo *freeBlock;
  // size of old block
  size_t oldSize = SIZE(oldBlock->sizeAndTags);
  // running sum to be size of final coalesced block
  size_t newSize = oldSize;
 
  // Coalesce with any preceding free block
  blockCursor = oldBlock;
  while ((blockCursor->sizeAndTags & TAG_PRECEDING_USED)==0) {
    // While the block preceding this one in memory (not the
    // prev. block in the free list) is free:
 
    // Get the size of the previous block from its boundary tag.
    size_t size = SIZE(*((size_t*)UNSCALED_POINTER_SUB(blockCursor, WORD_SIZE)));
    // Use this size to find the block info for that block.
    freeBlock = (BlockInfo*)UNSCALED_POINTER_SUB(blockCursor, size);
    // Remove that block from free list.
    removeFreeBlock(freeBlock);
 
    // Count that block's size and update the current block pointer.
    newSize += size;
    blockCursor = freeBlock;
  }
  newBlock = blockCursor;
 
  // Coalesce with any following free block.
  // Start with the block following this one in memory
  blockCursor = (BlockInfo*)UNSCALED_POINTER_ADD(oldBlock, oldSize);
  while ((blockCursor->sizeAndTags & TAG_USED)==0) {
    // While the block is free:
 
    size_t size = SIZE(blockCursor->sizeAndTags);
    // Remove it from the free list.
    removeFreeBlock(blockCursor);
    // Count its size and step to the following block.
    newSize += size;
    blockCursor = (BlockInfo*)UNSCALED_POINTER_ADD(blockCursor, size);
  }
 
  // If the block actually grew, remove the old entry from the free
  // list and add the new entry.
  if (newSize != oldSize) {
    // Remove the original block from the free list
    removeFreeBlock(oldBlock);
 
    // Save the new size in the block info and in the boundary tag
    // and tag it to show the preceding block is used (otherwise, it
    // would have become part of this one!).
    newBlock->sizeAndTags = newSize | TAG_PRECEDING_USED;
    // The boundary tag of the preceding block is the word immediately
    // preceding block in memory where we left off advancing blockCursor.
    *(size_t*)UNSCALED_POINTER_SUB(blockCursor, WORD_SIZE) = newSize | TAG_PRECEDING_USED;  
 
    // Put the new block in the free list.
    insertFreeBlock(newBlock);
  }
  return;
}
 
/* Get more heap space of size at least reqSize. */
static void requestMoreSpace(size_t reqSize) {
  size_t pagesize = mem_pagesize();
  size_t numPages = (reqSize + pagesize - 1) / pagesize;
  BlockInfo *newBlock;
  size_t totalSize = numPages * pagesize;
  size_t prevLastWordMask;
 
  void* mem_sbrk_result = mem_sbrk(totalSize);
  if ((size_t)mem_sbrk_result == -1) {
    printf("ERROR: mem_sbrk failed in requestMoreSpace\n");
    exit(0);
  }
  newBlock = (BlockInfo*)UNSCALED_POINTER_SUB(mem_sbrk_result, WORD_SIZE);
 
  /* initialize header, inherit TAG_PRECEDING_USED status from the
     previously useless last word however, reset the fake TAG_USED
     bit */
  prevLastWordMask = newBlock->sizeAndTags & TAG_PRECEDING_USED;
  newBlock->sizeAndTags = totalSize | prevLastWordMask;
  // Initialize boundary tag.
  ((BlockInfo*)UNSCALED_POINTER_ADD(newBlock, totalSize - WORD_SIZE))->sizeAndTags =
    totalSize | prevLastWordMask;
 
  /* initialize "new" useless last word
     the previous block is free at this moment
     but this word is useless, so its use bit is set
     This trick lets us do the "normal" check even at the end of
     the heap and avoid a special check to see if the following
     block is the end of the heap... */
  *((size_t*)UNSCALED_POINTER_ADD(newBlock, totalSize)) = TAG_USED;
 
  // Add the new block to the free list and immediately coalesce newly
  // allocated memory space
  insertFreeBlock(newBlock);
  coalesceFreeBlock(newBlock);
}
 
 
/* Print the heap by iterating through it as an implicit free list. */
 
static void examine_heap() {
  BlockInfo *block;
 
  //print to stderr so output isn't buffered and not output if we crash
  fprintf(stderr, "FREE_LIST_HEAD: %p\n", (void *)FREE_LIST_HEAD);
 
  for (block = (BlockInfo *)UNSCALED_POINTER_ADD(mem_heap_lo(), WORD_SIZE); // first block on heap
       SIZE(block->sizeAndTags) != 0 && (void*)block < (void*)mem_heap_hi();
       block = (BlockInfo *)UNSCALED_POINTER_ADD(block, SIZE(block->sizeAndTags))) {
 
    // print out common block attributes
    fprintf(stderr, "%p: %ld %ld %ld\t",
            (void *)block,
            SIZE(block->sizeAndTags),
            block->sizeAndTags & TAG_PRECEDING_USED,
            block->sizeAndTags & TAG_USED);
 
    // and allocated/free specific data
    if (block->sizeAndTags & TAG_USED) {
      fprintf(stderr, "ALLOCATED\n");
    } else {
      fprintf(stderr, "FREE\tnext: %p, prev: %p\n",
              (void *)block->next,
              (void *)block->prev);
    }
  }
  fprintf(stderr, "END OF HEAP\n\n");
}
 
/* Initialize the allocator. */
int mm_init () {
  // Head of the free list.
  BlockInfo *firstFreeBlock;
 
  // Initial heap size: WORD_SIZE byte heap-header (stores pointer to head
  // of free list), MIN_BLOCK_SIZE bytes of space, WORD_SIZE byte heap-footer.
  size_t initSize = WORD_SIZE+MIN_BLOCK_SIZE+WORD_SIZE;
  size_t totalSize;
 
  void* mem_sbrk_result = mem_sbrk(initSize);
  //  printf("mem_sbrk returned %p\n", mem_sbrk_result);
  if ((ssize_t)mem_sbrk_result == -1) {
    printf("ERROR: mem_sbrk failed in mm_init, returning %p\n",
           mem_sbrk_result);
    exit(1);
  }
 
  firstFreeBlock = (BlockInfo*)UNSCALED_POINTER_ADD(mem_heap_lo(), WORD_SIZE);
 
  // Total usable size is full size minus heap-header and heap-footer words
  // NOTE: These are different than the "header" and "footer" of a block!
  // The heap-header is a pointer to the first free block in the free list.
  // The heap-footer is used to keep the data structures consistent (see
  // requestMoreSpace() for more info, but you should be able to ignore it).
  totalSize = initSize - WORD_SIZE - WORD_SIZE;
 
  // The heap starts with one free block, which we initialize now.
  firstFreeBlock->sizeAndTags = totalSize | TAG_PRECEDING_USED;
  firstFreeBlock->next = NULL;
  firstFreeBlock->prev = NULL;
  // boundary tag
  *((size_t*)UNSCALED_POINTER_ADD(firstFreeBlock, totalSize - WORD_SIZE)) = totalSize | TAG_PRECEDING_USED;
 
  // Tag "useless" word at end of heap as used.
  // This is the is the heap-footer.
  *((size_t*)UNSCALED_POINTER_SUB(mem_heap_hi(), WORD_SIZE - 1)) = TAG_USED;
 
  // set the head of the free list to this new free block.
  FREE_LIST_HEAD = firstFreeBlock;
  return 0;
}
 
 
// TOP-LEVEL ALLOCATOR INTERFACE ------------------------------------
 
 
/* Allocate a block of size size and return a pointer to it. */
void split(BlockInfo* newBlock,size_t blockSize,size_t reqSize, BlockInfo* ptrFreeBlock,size_t precedingBlockUseTag){
  ptrFreeBlock->sizeAndTags = reqSize | precedingBlockUseTag; //update the tag preceeding used on the alllocated block
  newBlock = (BlockInfo*) UNSCALED_POINTER_ADD(ptrFreeBlock, reqSize); //updating the info of the remaining block
  newBlock->sizeAndTags = ((blockSize - reqSize) | TAG_PRECEDING_USED) & (~TAG_USED);
  *((size_t *) UNSCALED_POINTER_ADD(ptrFreeBlock, (reqSize - WORD_SIZE))) = reqSize;       // Footer for allocated block
  *((size_t *) UNSCALED_POINTER_ADD(ptrFreeBlock, (blockSize - WORD_SIZE))) = blockSize - reqSize; // Footer for newly created free block
  //add the free block to the head of the free list
  insertFreeBlock(newBlock);
}
 
void* mm_malloc (size_t size) {
  size_t reqSize; //this is the requested block size to malloc
  BlockInfo * ptrFreeBlock = NULL; //this is a pointer variable of type block info has attributes next, prev, size and tags
  size_t blockSize;
  size_t precedingBlockUseTag;
  // Zero-size requests get NULL.
  if (size == 0) {
    return NULL;
  }
  // Add one word for the initial size header.
  // Note that we don't need to boundary tag when the block is used!
  size += WORD_SIZE; //sets size to the size of a word
  if (size <= MIN_BLOCK_SIZE) {//Minimum block size (to account for size header, next ptr, prev ptr,  and boundary tag
    // Make sure we allocate enough space for a blockInfo in case we
    // free this block (when we free this block, we'll need to use the
    // next pointer, the prev pointer, and the boundary tag).
    reqSize = MIN_BLOCK_SIZE;
  } else {
    // Round up for correct alignment
    reqSize = ALIGNMENT * ((size + ALIGNMENT - 1) / ALIGNMENT);//Alignment of blocks returned by mm_malloc
  }
 // Implement mm_malloc.  You can change or remove any of the above
  // code.  It is included as a suggestion of where to start.
  // You will want to replace this return statement...
 
  // Finding the block. You may use searchFreeList(), requestMoreSpace()
  // examine_heap();
 
  // Remove this block from freelist
  //printf("this is for debugging purposes");
  ptrFreeBlock = searchFreeList(reqSize);//search throught the free list for a free block of size reqSize
  if(ptrFreeBlock == NULL) {
    // call request more space to get more free space
    requestMoreSpace(reqSize);
    ptrFreeBlock = searchFreeList(reqSize); //call search free list again but this time after we requested more space
    precedingBlockUseTag = TAG_PRECEDING_USED; //set the preceding block to used
  }else{
    precedingBlockUseTag = ptrFreeBlock->sizeAndTags & TAG_PRECEDING_USED;// checking to see if the preceeding block was used
  }
  blockSize = SIZE(ptrFreeBlock ->sizeAndTags); //check the size of the free block
  removeFreeBlock(ptrFreeBlock); //remove the free from the free list since it is going to be allocated
  //checking to see if the block has extra spaces
  if((blockSize - reqSize) > MIN_BLOCK_SIZE){
    BlockInfo* newBlock = (BlockInfo*)UNSCALED_POINTER_ADD(ptrFreeBlock, reqSize); //create a variable of type block info that has the same size of
    split(newBlock,blockSize,reqSize,ptrFreeBlock,precedingBlockUseTag);
    blockSize = reqSize;//update blocksize to be reqsize since i split off the spare blocks
  }
  else{
    //if there is no need to split
    //set the previous block used tag
    BlockInfo * nextBlock = (BlockInfo *) UNSCALED_POINTER_ADD(ptrFreeBlock,blockSize);
    nextBlock->sizeAndTags |= TAG_PRECEDING_USED;
    //udoate the header
    *((int*)UNSCALED_POINTER_ADD(ptrFreeBlock, (blockSize-WORD_SIZE)))= blockSize;
  }
 
  ptrFreeBlock ->sizeAndTags |= TAG_USED;
  //examine_heap();
  return ((void*)UNSCALED_POINTER_ADD(ptrFreeBlock,WORD_SIZE));
}
/* Free the block referenced by ptr.
The mm_free routine frees the block pointed to by ptr.
It returns nothing. This routine is guaranteed to work only when the passed
pointer (ptr) was returned by an earlier call to mm_malloc and has not yet been freed.
These semantics match the the semantics of the corresponding malloc and free routines in libc.
 Type man malloc in the shell for complete documentation.
 */
void mm_free (void *ptr) {
  size_t payloadSize;
  size_t blockSize;
  BlockInfo * blockInfo;
  BlockInfo * followingBlock;
 
  // Implement mm_free.  You can change or remove the declaraions
  // above.  They are included as minor hints.
  blockInfo = (BlockInfo*) UNSCALED_POINTER_SUB(ptr, WORD_SIZE); //going to the header of the block
  followingBlock = (BlockInfo*) UNSCALED_POINTER_ADD(blockInfo, SIZE(blockInfo->sizeAndTags));//going to the footer of the block
 
  blockSize = SIZE(blockInfo->sizeAndTags); //getting the block size of the block size of the block
  payloadSize = blockSize - WORD_SIZE; //getting the size of the payload
 
  blockInfo->sizeAndTags = blockInfo->sizeAndTags & ~TAG_USED; //makeing the block unused since i am going to free it
  *((size_t*) UNSCALED_POINTER_ADD(blockInfo, payloadSize)) = blockInfo->sizeAndTags;
  followingBlock->sizeAndTags &= ~TAG_PRECEDING_USED; //setting the preceeding to to be unused
//check to see if the footer shows that the following tag is used or not
  if ((followingBlock->sizeAndTags & TAG_USED) == 0) {
  *((size_t*) UNSCALED_POINTER_ADD(followingBlock, SIZE(followingBlock->sizeAndTags) - WORD_SIZE)) = followingBlock->sizeAndTags; //
  }
  insertFreeBlock(blockInfo); //insert the block into the free list
  coalesceFreeBlock(blockInfo); //coalesce
}
 
// Implement a heap consistency checker as needed.
int mm_check() {
  return 0;
}
// Extra credit.
/*
The realloc() function changes the size of the memory block pointed to by
ptr to size bytes.  The contents will be unchanged in the range from the
start of the region up to the minimum of the old and new sizes.  If the
new size is larger than the old size, the added memory will not be
initialized.  If ptr is NULL, then the call is equivalent to
malloc(size), for all values of size; if size is equal to zero, and ptr
is not NULL, then the call is equivalent to free(ptr).  Unless ptr is
NULL, it must have been returned by an earlier call to malloc(), calloc()
or realloc().  If the area pointed to was moved, a free(ptr) is done.
*/
 
void* mm_realloc(void* ptr, size_t size) {
  // ... implementation here ...
  //printf("this is debugging\n");
  BlockInfo * oldBlockInfo;
  BlockInfo* newBlockInfo;
  size_t ptrSize;
  void* newPtr;
  if(ptr == NULL){
  return mm_malloc(size);
  }
  else{
    if(size == 0){
      mm_free(ptr);
      return NULL;
    }
  }
  //check if area pointed was moved ???
  //ToDo - change size of memory black pointed by ptr to size bytes
  //getting original block size
  oldBlockInfo = (BlockInfo*) UNSCALED_POINTER_SUB(ptr, WORD_SIZE);
  ptrSize = SIZE(oldBlockInfo->sizeAndTags); //getting the size of the old block
  //checking size
  if (ptrSize >= size){//if old size is greater or equal return old pointer
  return ptr;//return the pointer to the old block
  }
  else{
    /*newPtr = mm_malloc(size);
    myMemcpy(ptr,newPtr,size);*/
    //printf("this is debugging 2\n");
    newPtr = mm_malloc(size); //set a block of the requested size to the new pointer
    newBlockInfo = (BlockInfo*)UNSCALED_POINTER_ADD(newPtr,WORD_SIZE);  //create a new instance of struct blockinfo
    //ptrSize = SIZE(newBlockInfo->sizeAndTags);
    //printf("this is the pointer size 1: %d\n", (int)ptrSize);
    ptrSize -= WORD_SIZE; // subtract the header size
    //printf("this is the pointer 2: %d",(int) ptrSize);
    char *tempPtr = newPtr; //cas the void pointer to a char to prevent error
    char *oldPtr = ptr;
    //printf("this is debugging 2.5\n");
    for (int i = 0; i<ptrSize - WORD_SIZE; i+=WORD_SIZE){ //iterate throught the payload
      tempPtr[i] = oldPtr[i];
    }
    //examine_heap();
    //printf("this is debugging 3\n");
    //mm_free(ptr);
    return (void*)tempPtr;
  }
}
 


